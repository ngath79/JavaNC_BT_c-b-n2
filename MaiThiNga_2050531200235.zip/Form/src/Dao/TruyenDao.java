/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import FormHelper.DatabaseHelper;
import FormModel.Truyen;
import FormHelper.DatabaseHelper;
import FormModel.NguoiDung;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import static java.util.Collections.list;

/**
 *
 * @author 84932
 */
public class TruyenDao {
    public boolean insert(Truyen tr) throws Exception{
        
        String sql = "insert into [dbo].[Truyen] (MaID, TenTruyen, TheLoai, NhaXuatBan, Gia)" + " values(?, ?, ?, ?, ?)";
        
        try (
                Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);
                ){
            pstmt.setString(1, tr.getMaID());
            pstmt.setString(2, tr.getTenTruyen());
            pstmt.setString(3, tr.getTheLoai());
            pstmt.setString(4, tr.getNhaXuatBan());
            pstmt.setString(5, tr.getGiaBan());
            
            return pstmt.executeUpdate() > 0;
            
        }    
            
    }
    
    
    public boolean update(Truyen tr) throws Exception{
        
        String sql = "update [dbo].[Truyen]\n " + "   SET ( TenTruyen = ?, TheLoai = ?, NhaXuatBan = ?, Gia = ?)" + "  where MaID = ?";
        
        try (
                Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);
                ){
            pstmt.setString(5, tr.getMaID());
            pstmt.setString(1, tr.getTenTruyen());
            pstmt.setString(2, tr.getTheLoai());
            pstmt.setString(3, tr.getNhaXuatBan());
            pstmt.setString(4, tr.getGiaBan());
            
            return pstmt.executeUpdate() > 0;
            
        }    
            
    }
    
    public boolean delete(String maID) throws Exception{
        
        String sql = "delete from Truyen" + " where MaID = ?";
        
        try (
                Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);
                ){
            pstmt.setString(1, maID);
            
            return pstmt.executeUpdate() > 0;
            
        }    
            
    }
    
    public Truyen findById(String maID) throws Exception{
        
        String sql = "select * from Truyen where MaID = ?";
        
        try (
                Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);
                ){
            pstmt.setString(1, maID);
            try(ResultSet rs = pstmt.executeQuery();) {
                if(rs.next()) {
                    Truyen tr = new Truyen();
                    tr.setMaID(rs.getString("Ma ID"));
                    tr.setTenTruyen(rs.getString("Ten truyen"));
                    tr.setTheLoai(rs.getString("The loai"));
                    tr.setNhaXuatBan(rs.getString("Nha Xuat Ban"));
                    tr.setGiaBan(rs.getString("Gia ban"));
                    return tr;
                }
            }
            
            return null;
            
        }    
            
    }
    
//    public List< Truyen> findAll() throws Exception{
//        String sql = "select * from Truyen";
//        try (
//                Connection con = DatabaseHelper.openConnection();
//                PreparedStatement pstmt = con.prepareStatement(sql);
//                ){
//            try(ResultSet rs = pstmt.executeQuery();) {
//                List <Truyen> list = new ArrayList<>();
//                while (rs.next()) {
//                    Truyen tr = new Truyen();
//                    tr.setMaID(rs.getString("Ma ID"));
//                    tr.setTenTruyen(rs.getString("Ten truyen"));
//                    tr.setTheLoai(rs.getString("The loai"));
//                    tr.setNhaXuatBan(rs.getString("Nha Xuat Ban"));
//                    tr.setGiaBan(rs.getString("Gia ban"));
//                    list.add(tr);
//                }
//                return list;
//            }
//             
//        }    
//            
//    }
}
