/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormModel;

/**
 *
 * @author 84932
 */
public class Truyen {
    private String MaID, tenTruyen, theLoai, nhaXuatBan, giaBan;

    public Truyen() {
    }

    public Truyen(String MaID, String tenTruyen, String theLoai, String nhaXuatBan, String giaBan) {
        this.MaID = MaID;
        this.tenTruyen = tenTruyen;
        this.theLoai = theLoai;
        this.nhaXuatBan = nhaXuatBan;
        this.giaBan = giaBan;
    }

    public String getMaID() {
        return MaID;
    }

    public void setMaID(String MaID) {
        this.MaID = MaID;
    }

    public String getTenTruyen() {
        return tenTruyen;
    }

    public void setTenTruyen(String tenTruyen) {
        this.tenTruyen = tenTruyen;
    }

    public String getTheLoai() {
        return theLoai;
    }

    public void setTheLoai(String theLoai) {
        this.theLoai = theLoai;
    }

    public String getNhaXuatBan() {
        return nhaXuatBan;
    }

    public void setNhaXuatBan(String nhaXuatBan) {
        this.nhaXuatBan = nhaXuatBan;
    }

    public String getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(String giaBan) {
        this.giaBan = giaBan;
    }
    
    
}
