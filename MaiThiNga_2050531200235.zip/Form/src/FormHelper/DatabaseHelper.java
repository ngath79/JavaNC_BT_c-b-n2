/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormHelper;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.sun.jdi.connect.spi.Connection;
//import java.sql.Connection;
import java.sql.DriverManager;


public class DatabaseHelper {
    public static void main(String[] args) throws Exception {
        
        SQLServerDataSource ds = new SQLServerDataSource();
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String connectionUrl = "jdbc:sqlserver://MTN\\SQLEXPRESS;database=StoryManageranager";
        String dbusername = "sa";
        String password = "123456";
        Connection con = (Connection) DriverManager.getConnection(connectionUrl, dbusername, password);
    }

    public static java.sql.Connection openConnection() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
