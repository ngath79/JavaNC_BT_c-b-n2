
package form;

import javax.swing.JFrame;


public class MainForm extends javax.swing.JFrame {

    private StoryManagermentPanel sManagerPanel;
    private GPAManagermentPanel gManagerPanel;
    
    public MainForm() {
        initComponents();
        setLocationRelativeTo(null);
        
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        tbrLognOut = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        tbrAboutUs = new javax.swing.JButton();
        tplMainBoard = new javax.swing.JTabbedPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        menuFile_Exit = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        menuManagerStory = new javax.swing.JMenuItem();
        menuManagerUser = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        menuAboutUs = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jToolBar1.setBackground(new java.awt.Color(0, 255, 153));
        jToolBar1.setRollover(true);

        tbrLognOut.setBackground(new java.awt.Color(0, 255, 153));
        tbrLognOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tbrLognOut.setText("Đăng Xuất");
        tbrLognOut.setFocusable(false);
        tbrLognOut.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbrLognOut.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbrLognOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbrLognOutActionPerformed(evt);
            }
        });
        jToolBar1.add(tbrLognOut);
        jToolBar1.add(jSeparator1);

        jButton2.setBackground(new java.awt.Color(0, 255, 153));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Quản Lý Người Dùng");
        jButton2.setFocusable(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(jButton2);

        jButton3.setBackground(new java.awt.Color(0, 255, 153));
        jButton3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton3.setText("Quản Lý Truyện");
        jButton3.setFocusable(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(jButton3);
        jToolBar1.add(jSeparator2);

        tbrAboutUs.setBackground(new java.awt.Color(0, 255, 153));
        tbrAboutUs.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tbrAboutUs.setText("Giới Thiệu");
        tbrAboutUs.setFocusable(false);
        tbrAboutUs.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tbrAboutUs.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tbrAboutUs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbrAboutUsActionPerformed(evt);
            }
        });
        jToolBar1.add(tbrAboutUs);

        jMenuBar1.setBackground(new java.awt.Color(0, 255, 153));

        jMenu1.setBackground(new java.awt.Color(255, 102, 102));
        jMenu1.setText("Hệ Thống");
        jMenu1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem2.setText("Đăng Xuất");
        jMenu1.add(jMenuItem2);

        menuFile_Exit.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuFile_Exit.setText("Thoát");
        menuFile_Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFile_ExitActionPerformed(evt);
            }
        });
        jMenu1.add(menuFile_Exit);

        jMenuBar1.add(jMenu1);

        jMenu2.setBackground(new java.awt.Color(255, 102, 102));
        jMenu2.setText("Quản Lý");
        jMenu2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        menuManagerStory.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuManagerStory.setText("Quản Lý Người Dùng");
        menuManagerStory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuManagerStoryActionPerformed(evt);
            }
        });
        jMenu2.add(menuManagerStory);

        menuManagerUser.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuManagerUser.setText("Quản Lý Truyện");
        menuManagerUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuManagerUserActionPerformed(evt);
            }
        });
        jMenu2.add(menuManagerUser);

        jMenuBar1.add(jMenu2);

        jMenu3.setBackground(new java.awt.Color(255, 102, 102));
        jMenu3.setText("Trợ Giúp");
        jMenu3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jMenuItem6.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        jMenuItem6.setText("Nội Dung");
        jMenu3.add(jMenuItem6);

        menuAboutUs.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuAboutUs.setText("Giới Thiệu");
        menuAboutUs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuAboutUsActionPerformed(evt);
            }
        });
        jMenu3.add(menuAboutUs);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tplMainBoard, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tplMainBoard, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuAboutUsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuAboutUsActionPerformed
        // TODO add your handling code here:
        tbrAboutUsActionPerformed(evt);
    }//GEN-LAST:event_menuAboutUsActionPerformed

    private void menuFile_ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFile_ExitActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_menuFile_ExitActionPerformed

    private void menuManagerStoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuManagerStoryActionPerformed
        // TODO add your handling code here:
        if(sManagerPanel == null) {
            sManagerPanel = new StoryManagermentPanel();
            tplMainBoard.addTab("Quản Lý Người Dùng", sManagerPanel);
        }
        tplMainBoard.setSelectedComponent(sManagerPanel);
    }//GEN-LAST:event_menuManagerStoryActionPerformed

    private void menuManagerUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuManagerUserActionPerformed
        // TODO add your handling code here:
        if(gManagerPanel == null) {
            gManagerPanel = new GPAManagermentPanel();
            tplMainBoard.addTab("Quản Lý Truyện", gManagerPanel);
        }
        tplMainBoard.setSelectedComponent(gManagerPanel);
    }//GEN-LAST:event_menuManagerUserActionPerformed

    private void tbrAboutUsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbrAboutUsActionPerformed
        // TODO add your handling code here:
        AboutUsDialog aboutDialog = new AboutUsDialog(this, true);
        
        aboutDialog.setVisible(true);
    }//GEN-LAST:event_tbrAboutUsActionPerformed

    private void tbrLognOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbrLognOutActionPerformed
        // TODO add your handling code here:
        LogninDialog logninDialog = new LogninDialog(this, true);
        
        logninDialog.setVisible(true);
    }//GEN-LAST:event_tbrLognOutActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        LogninDialog dialog = new LogninDialog(this, true);
        dialog.setVisible(true);
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JMenuItem menuAboutUs;
    private javax.swing.JMenuItem menuFile_Exit;
    private javax.swing.JMenuItem menuManagerStory;
    private javax.swing.JMenuItem menuManagerUser;
    private javax.swing.JButton tbrAboutUs;
    private javax.swing.JButton tbrLognOut;
    private javax.swing.JTabbedPane tplMainBoard;
    // End of variables declaration//GEN-END:variables
}
